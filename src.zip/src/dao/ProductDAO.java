/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import model.Product;
import util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Achintha
 */
public class ProductDAO {

    public List<Product> getAllActiveProducts() throws Exception {

        List<Product> products = new ArrayList<>();

        String sql =
                "SELECT product_id, product_code, product_name, "
                + "category_id, unit, selling_price, reorder_level, status "
                + "FROM products "
                + "WHERE status = 'ACTIVE' "
                + "ORDER BY product_name";

        try (
            Connection con = DBConnection.getConnection();
            PreparedStatement pst = con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery()
        ) {

            while (rs.next()) {

                Product product = new Product();

                product.setProductId(
                        rs.getInt("product_id")
                );

                product.setProductCode(
                        rs.getString("product_code")
                );

                product.setProductName(
                        rs.getString("product_name")
                );

                product.setCategoryId(
                        rs.getInt("category_id")
                );

                product.setUnit(
                        rs.getString("unit")
                );

                product.setSellingPrice(
                        rs.getDouble("selling_price")
                );

                product.setReorderLevel(
                        rs.getDouble("reorder_level")
                );

                product.setStatus(
                        rs.getString("status")
                );

                products.add(product);
            }
        }

        return products;
    }    
}
